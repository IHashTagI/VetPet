package vetApplication;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.layout.VBox;

public class vetAppointmentController {

    @FXML
    private VBox vetAppointmentBox;

    @FXML
    void goToVetHomePage(ActionEvent event) {

    }

}
